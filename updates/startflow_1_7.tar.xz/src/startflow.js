// STEEL RUSH 1.7 — reliable race launch, no tutorial overlay, optional cinematic.
// The default is an immediate, fully controllable race. A flyover is opt-in.
const $ = id => document.getElementById(id);
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const mix = (a, b, t) => a + (b - a) * t;
const ease = t => { t = clamp(t, 0, 1); return t*t*(3-2*t); };
const FLYOVER_TIME = 4.25;
const COUNTDOWN_TIME = 3.0;
export const INTRO_DURATION = FLYOVER_TIME + COUNTDOWN_TIME;

// Exported to keep launch transition testable without a browser/WebGL context.
export function releaseControls(game, ui = {}) {
  game.mode = 'race';
  game.fixedAcc = 0;
  game.mouseDx = 0;
  game.mouseDy = 0;
  // Deliberately do NOT clear controls: holding W during "3, 2, 1" works on GO.
  if (ui.raceUI) ui.raceUI.classList.remove('hidden');
  if (ui.notice) { ui.notice.textContent = ''; ui.notice.classList.remove('visible'); }
  game.toasted = 0;
  if (game.canvas) {
    if (game.canvas.tabIndex < 0) game.canvas.tabIndex = 0;
    try { game.canvas.focus?.({preventScroll:true}); } catch (_) {}
  }
}

export function installStartFlow(game) {
  if (game._sr17Installed) return game._sr17Installed;
  const ui={raceUI:$('race-ui'),notice:$('notice')};
  const sheet=$('sr13-briefing');
  const style=document.createElement('style');
  style.textContent=`
  .sr17-option{display:flex;gap:9px;align-items:center;cursor:pointer;font:700 11px Segoe UI,Arial,sans-serif;color:#d9e7e3;white-space:normal;flex:1 1 175px}
  .sr17-option input{accent-color:#e8b578;width:17px;height:17px;flex:none;cursor:pointer}
  .sr17-intro{position:absolute;inset:0;z-index:25;pointer-events:none;overflow:hidden}
  .sr17-intro[hidden]{display:none!important}
  .sr17-intro .matte{position:absolute;left:0;right:0;height:6.5vh;background:#061316df}
  .sr17-intro .top{top:0}.sr17-intro .bottom{bottom:0}
  .sr17-intro .digits{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font:clamp(126px,19vw,250px) Impact,Arial,sans-serif;color:#fff1d3;text-shadow:0 0 35px #142322b8,0 7px 15px #000c;letter-spacing:.02em}
  .sr17-intro .digits[hidden]{display:none!important}
  .sr17-intro button{pointer-events:auto;position:absolute;right:23px;bottom:23px;padding:10px 18px;border:1px solid #ccad7e;background:#14282de8;color:#f5ddbd;font:800 12px Segoe UI,sans-serif;cursor:pointer}
  .sr17-intro button:hover{background:#34454a}
  #sr14-guide,#sr14-intro{display:none!important}
  #game-ui .control-hints,#game-ui .sr15-title{display:none!important}
  @media(max-width:650px){.sr17-intro button{right:10px;bottom:12px;padding:8px 12px}}
  `;
  document.head.appendChild(style);
  const opt=document.createElement('label');opt.className='sr17-option';
  const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.id='sr17-cinematic';checkbox.checked=false;
  opt.appendChild(checkbox);opt.appendChild(document.createTextNode('Пролёт камеры перед стартом (необязательно)'));
  const foot=sheet?.querySelector('.sr13-foot');
  if(foot){const start=$('sr13-start');foot.insertBefore(opt,start||null);}
  const root=document.createElement('section');root.id='sr17-intro';root.className='sr17-intro';root.hidden=true;
  root.innerHTML='<div class="matte top"></div><div class="matte bottom"></div><div class="digits" id="sr17-digits" hidden></div><button id="sr17-skip" type="button">Пропустить</button>';
  $('game-ui').appendChild(root);
  const digits=root.querySelector('#sr17-digits'),skip=root.querySelector('#sr17-skip');
  const originalStart=game.startRace.bind(game),originalDraw=game.draw.bind(game),originalGarage=game.garage.bind(game);
  let active=false,elapsed=0,drawErrors=0;
  function hideStartHints(){
    const guide=$('sr14-guide');if(guide)guide.hidden=true;
    const original=$('sr14-intro');if(original)original.classList.add('hidden');
    if(ui.notice){ui.notice.textContent='';ui.notice.classList.remove('visible');}
    game.toasted=0;
  }
  function complete(){
    if(!active)return;
    active=false;root.hidden=true;digits.hidden=true;
    hideStartHints();releaseControls(game,ui);
    // Avoid a accumulated catch-up step that could look like a stall after GO.
    if(typeof performance!=='undefined')game.last=performance.now();
  }
  function begin(){
    active=true;elapsed=0;drawErrors=0;root.hidden=false;digits.hidden=true;
    hideStartHints();ui.raceUI?.classList.add('hidden');
    game.mode='intro';game.fixedAcc=0;
    game.controls?.clear?.(); // One-time reset before the camera starts, NOT after the countdown.
    game.mouseDx=0;game.mouseDy=0;
    // No forced pointer lock during the cinematic; controls will work on GO.
    try { document.exitPointerLock?.(); } catch (_) {}
  }
  function frame(dt){
    if(!active) return originalDraw(dt);
    elapsed += clamp(Number.isFinite(dt)?dt:0,0,.08);
    if(elapsed>=INTRO_DURATION){complete();return originalDraw(dt);}
    if(elapsed>=FLYOVER_TIME){
      digits.hidden=false;
      const sec=clamp(Math.ceil(INTRO_DURATION-elapsed),1,3);
      digits.textContent=String(sec);
    }else digits.hidden=true;
    const world=game.world, r=game.r;
    if(!world?.pointAt||!r?.begin){complete();return originalDraw(dt);}
    try {
      let eye, look;
      if(elapsed<FLYOVER_TIME){
        const p=ease(elapsed/FLYOVER_TIME),f=mix(.015,.090,p),at=world.pointAt(f),toward=world.tangentAt(f),ahead=world.pointAt(f+.015);
        eye=[at.x-toward.x*27-toward.z*26,at.y+mix(22,12,p),at.z-toward.z*27+toward.x*26];
        look=[ahead.x,ahead.y+1.4,ahead.z];
      }else{
        const tank=game.tank,yaw=tank.yaw,s=ease((elapsed-FLYOVER_TIME)/1.3),d=mix(18,11,s);
        eye=[tank.x+Math.sin(yaw)*d,tank.y+mix(9.5,5.4,s),tank.z+Math.cos(yaw)*d];
        look=[tank.x-Math.sin(yaw)*5,tank.y+2.15,tank.z-Math.cos(yaw)*5];
      }
      r.begin(eye,look);world.draw(r);
      game.drawTank(game.tank,game.selected,game.tank.turret);
      for(const bot of game.bots)game.drawTank(bot,bot.spec,bot.turretAim??(bot.yaw+bot.turret));
      world.drawGates?.(r,{time:game.now,active:game.tank.checkpoint,mode:'intro'});
      game.combat?.draw?.(r,game.now);
      r.end();
    }catch(err){
      console.error('[STEEL RUSH] Intro rendering failed, restoring driving:',err);
      drawErrors++;
      complete();
      // If the camera renderer fails, the normal game must still resume.
    }
  }
  game.startRace=function(...args){
    originalStart(...args);
    hideStartHints();
    if(checkbox.checked)begin();
    else {active=false;root.hidden=true;releaseControls(game,ui);}
  };
  game.draw=function(dt){return active?frame(dt):originalDraw(dt);};
  game.garage=function(...args){active=false;root.hidden=true;return originalGarage(...args);};
  skip.addEventListener('click',()=>complete());
  // Capturing these keys avoids interference with base Escape/pause handlers.
  window.addEventListener('keydown',e=>{
    if(!active||!['Enter','Space','Escape'].includes(e.code))return;
    e.preventDefault?.();e.stopImmediatePropagation?.();complete();
  },true);
  const api={get active(){return active;},get elapsed(){return elapsed;},get drawErrors(){return drawErrors;},skip:complete,toggle:checkbox};
  game._sr17Installed=api;
  return api;
}
