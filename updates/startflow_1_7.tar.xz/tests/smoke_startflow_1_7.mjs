// STEEL RUSH 1.7 regression tests: no forced lock, seamless start, held-W works.
import assert from 'node:assert/strict';
import {Game,TANKS} from '../src/game.js';
import {installStartFlow,releaseControls,INTRO_DURATION} from '../src/startflow.js';

class FakeElement {
 constructor(id='') {this.id=id;this.hidden=false;this.innerHTML='';this.textContent='';this.tabIndex=-1;this.checked=false;this.children=[];this.listeners={};this.classList={values:new Set(),add:(x)=>this.classList.values.add(x),remove:(x)=>this.classList.values.delete(x),contains:(x)=>this.classList.values.has(x)};}
 appendChild(x){this.children.push(x);return x;}
 insertBefore(x,y){this.children.push(x);return x;}
 addEventListener(key,fn){this.listeners[key]=fn;}
 querySelector(sel){return this.selectors?.[sel]||null;}
 focus(){this.focused=true;}
}
const ids=new Map();for(const id of ['race-ui','notice','sr13-briefing','sr13-start','game-ui','sr14-guide','sr14-intro'])ids.set(id,new FakeElement(id));
ids.get('sr13-briefing').selectors={'.sr13-foot':new FakeElement('foot')};
const doc={head:new FakeElement('head'),getElementById:id=>ids.get(id)||null,createElement:tag=>{
 const el=new FakeElement(tag);
 if(tag==='section')el.selectors={'#sr17-digits':new FakeElement('digits'),'#sr17-skip':new FakeElement('skip')};
 return el;
},createTextNode:text=>({textContent:text}),exitPointerLock() {}};
globalThis.document=doc;
const listeners={};globalThis.window={addEventListener(name,fn){listeners[name]=fn;}};
const oldPerformance=globalThis.performance;
const world={
 pointAt(f){return {x:f*1000,y:1,z:50}},tangentAt(){return {x:1,z:0}},
 surfaceAt(){return {name:'ROAD',code:'ROAD',y:1}},limitToCorridor(x,z){return {x,z,hit:false}},hitWalls(x,z){return {x,z,hit:false}},
 checkpoints:[{x:999999,z:999999,radius_m:1}],data:{main_length_m:3000},draw(){},drawGates(){}
};
function newGame(){
 const selected=TANKS[1],tank={x:0,y:1,z:50,yaw:0,turret:0,gunPitch:0,forward:0,lateral:0,boost:100,hp:selected.health,checkpoint:0,lap:1,lapStart:0,best:0,shotCooldown:0,damageCooldown:0,shieldTimer:0,turboTimer:0,hitShake:0};
 const game={mode:'menu',controls:new Set(),world,tank,selected,bots:[],combat:{update(){},draw(){}},cameraShake:0,damageFlash:0,smoke:[],smokeAccum:0,now:0,time:0,fixedAcc:0,mouseDx:0,mouseDy:0,cameraOrbit:0,pitchOffset:0,
 canvas:new FakeElement('scene'),toasted:0,r:{begin(){},end(){}},drawTank(){},
 startRace(){this.mode='race';this.time=0;this.fixedAcc=0;this.controls.clear();this.tank.forward=0;this.cameraShake=0;this.damageFlash=0;this.smoke=[];this.smokeAccum=0;},draw(){this.normalDraws=(this.normalDraws||0)+1;},garage(){this.mode='menu';},toast(){throw Error('No start tips should be shown')},finish(){this.mode='finished'}
 };
 return game;
}
let n=0;const pass=(name)=>{console.log(`PASS ${++n}: ${name}`);};
{
 const g=newGame(),api=installStartFlow(g);
 assert.equal(api.active,false);assert.equal(api.toggle.checked,false);pass('cinematic is opt-in, disabled by default');
 g.startRace({type:'race'});assert.equal(g.mode,'race');assert.equal(api.active,false);assert.equal(ids.get('race-ui').classList.contains('hidden'),false);pass('race begins immediately, no frozen pre-start mode');
 g.controls.add('KeyW');const oldZ=g.tank.z;for(let i=0;i<30;i++)Game.prototype.update.call(g,1/60);
 assert.ok(g.time>.45);assert.ok(g.tank.forward>0);assert.notEqual(g.tank.z,oldZ);pass('player accelerates and moves with W in normal race');
 g.garage();assert.equal(g.mode,'menu');pass('garage returns to menu');
 api.toggle.checked=true;g.startRace({type:'race'});assert.equal(g.mode,'intro');assert.equal(api.active,true);pass('optional camera flyover enters intro mode');
 g.controls.add('KeyW');for(let i=0;i<460;i++){g.draw(1/60);if(!api.active)break;}
 assert.equal(g.mode,'race');assert.equal(api.active,false);assert.equal(g.controls.has('KeyW'),true);pass('flyover and 3-2-1 release controls automatically without dropping held W');
 const z=g.tank.z;Game.prototype.update.call(g,1/60);assert.ok(g.tank.forward>0);assert.notEqual(g.tank.z,z);pass('first physics step after flyover advances the tank');
 g.garage();g.startRace();assert.equal(g.mode,'intro');api.skip();assert.equal(g.mode,'race');assert.equal(api.active,false);pass('skip instantly starts driving without second confirmation');
 g.garage();g.startRace();g.controls.add('KeyW');listeners.keydown?.({code:'Enter',preventDefault(){},stopImmediatePropagation(){}});
 assert.equal(g.mode,'race');assert.equal(g.controls.has('KeyW'),true);pass('keyboard skip keeps driving input');
 g.garage();g.startRace();g.r.begin=()=>{throw Error('fake render fault')};const previous=console.error;console.error=()=>{};
 try{g.draw(1/60)}finally{console.error=previous;}
 assert.equal(g.mode,'race');assert.equal(api.active,false);pass('intro renderer error fails open instead of leaving tank blocked');
}
{
 const g=newGame();g.controls.add('KeyW');g.fixedAcc=0.5;
 releaseControls(g,{raceUI:ids.get('race-ui'),notice:ids.get('notice')});
 assert.equal(g.mode,'race');assert.equal(g.controls.has('KeyW'),true);assert.equal(g.fixedAcc,0);pass('transition preserves user input and resets accumulated physics');
}
assert.ok(INTRO_DURATION>6 && INTRO_DURATION<9);pass('intro duration bounded and short');
console.log(`STEEL RUSH 1.7: ${n}/${n} regression tests passed`);
